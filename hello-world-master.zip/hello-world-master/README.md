# hello-world
Learning to make a repository

I'm Manan. Ive just started to dive deep into the computer stuff and started to realise just how much I took for granted. A lot of work goes even into a very small applications. Nevertheless I'm now all set to learn more.
